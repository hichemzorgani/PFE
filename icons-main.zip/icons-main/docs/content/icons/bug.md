---
title: Bug
categories:
  - Real world
tags:
  - insect
  - error
---
