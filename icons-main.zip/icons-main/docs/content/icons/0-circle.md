---
title: 0 circle
categories:
  - Shapes
tags:
  - number
  - numeral
added: 1.10.0
---
