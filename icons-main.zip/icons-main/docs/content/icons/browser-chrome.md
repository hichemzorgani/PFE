---
title: Browser Chrome
categories:
  - Brand
tags:
  - google
  - webkit
  - blink
added: 1.10.0
---
