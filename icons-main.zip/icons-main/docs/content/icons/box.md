---
title: Box
categories:
  - Real world
tags:
  - cardboard
  - package
  - cube
---
