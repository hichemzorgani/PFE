---
title: 8 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
